"""Freeze the method before new evidence; preserve every qualified observation."""
from ..canonical import digest
from .catalog import PROFILE, inventory
from .engine import investigate, method_identity
from .evidence import fields, instant


def freeze(*, at, known_source_hashes):
    instant(at)
    if not isinstance(known_source_hashes, list) or any(not isinstance(x, str) or len(x) != 64 for x in known_source_hashes):
        raise ValueError("Explicit prior source identities required")
    result = {"at": at, "method_hash": method_identity(), "profile": PROFILE,
              "inventory_hash": digest(inventory(PROFILE)), "known_source_hashes": sorted(set(known_source_hashes)),
              "scoring": "Formal obligations, counterexamples and preserved qualifications; no human labels"}
    return {**result, "freeze_hash": digest(result)}


def observe(frozen, request, store):
    fields(frozen, {"at", "method_hash", "profile", "inventory_hash", "known_source_hashes", "scoring", "freeze_hash"})
    if frozen != freeze(at=frozen["at"], known_source_hashes=frozen["known_source_hashes"]):
        raise ValueError("Method, inventory or freeze changed; start a new prospective series")
    if request["profile"] != frozen["profile"] or instant(request["context"]["known_at"]) <= instant(frozen["at"]):
        raise ValueError("Observation must follow the frozen method")
    registry = store.json(request["registry_sha256"])
    new = {r["blob"] for r in registry.values()} - set(frozen["known_source_hashes"])
    if not new:
        raise ValueError("No previously unseen source content")
    result = investigate(request, store)
    return {"freeze_hash": frozen["freeze_hash"], "new_source_hashes": sorted(new), "investigation": result,
            "novelty": "NEW_TO_DECLARED_SOURCE_INVENTORY", "chronology": "DECLARED_TIMES_NOT_EXTERNALLY_ATTESTED",
            "prospective_legal_accuracy": "NOT_ESTABLISHED", "human_quality_evidence": False}

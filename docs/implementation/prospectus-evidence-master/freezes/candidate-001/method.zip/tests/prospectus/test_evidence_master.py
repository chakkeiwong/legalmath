import pytest
from legalmath.prospectus import master_mechanisms as m


def test_contingent_debt_metadata_keeps_neutral_context_without_claiming_scope():
    issue={"id":"santander-at1-eur-2025","security_type":"coco_debt"}
    result=m.issue_context({"context":{"instrument_id":"old","instrument_kind":"at1_bond"}},issue)
    assert result["context"]=={"instrument_id":issue["id"],"instrument_kind":"debt_bond"}


@pytest.mark.parametrize("kind",["equity","preferred_stock","unknown"])
def test_context_does_not_guess_debt_from_unrecognized_type(kind):
    with pytest.raises(ValueError):m.issue_context({"context":{}},{"id":"x","security_type":kind})


from copy import deepcopy
from fractions import Fraction
from pathlib import Path
import json
from types import SimpleNamespace

import pytest

from legalmath.prospectus import master_control as c
from legalmath.prospectus import master_mechanisms as m
from legalmath.prospectus import master_sources as s


@pytest.mark.parametrize("value",[True,False,1.25,"-1","NaN","1,000","EUR 2","1e3"])
def test_exact_money_rejects_invalid_or_inexact_values(value):
    with pytest.raises((ValueError,ZeroDivisionError)):m.amount(value)


@pytest.mark.parametrize("ratio,expected",[("0.051249",True),("0.05125",False),("0.051251",False)])
@pytest.mark.parametrize("loss",["0","25","50","200","500"])
def test_write_down_threshold_cap_and_conservation(ratio,expected,loss):
    out=m.write_down(ratio=ratio,required_loss=loss,principal="100",others=[{"currency":"EUR","principal":"100","effective":True},{"currency":"EUR","principal":"999","effective":False}],currency="EUR",premise_kind="HYPOTHETICAL")
    assert out["trigger_under_premises"]==expected
    independent=min(Fraction(loss),200)/2 if expected else 0
    assert Fraction(out["write_down"])==independent
    assert Fraction(out["write_down"])+Fraction(out["remaining_principal"])==100


def test_ineffective_other_instrument_cannot_dilute_loss():
    kwargs=dict(ratio="0.05",required_loss="50",principal="100",currency="EUR",premise_kind="HYPOTHETICAL")
    effective=m.write_down(**kwargs,others=[{"currency":"EUR","principal":"100","effective":True}])
    ineffective=m.write_down(**kwargs,others=[{"currency":"EUR","principal":"100","effective":False}])
    assert effective["write_down"]=="25" and ineffective["write_down"]=="50"


@pytest.mark.parametrize("other",[{"currency":"USD","principal":"100","effective":True},{"currency":"EUR","principal":"100","effective":None}])
def test_units_and_missing_effectiveness_rejected(other):
    with pytest.raises(ValueError):m.write_down(ratio="0.05",required_loss="50",principal="100",others=[other],currency="EUR",premise_kind="HYPOTHETICAL")


CONDITIONS=["subsequent_financial_year","no_annual_loss_created","no_continuing_or_recreated_trigger","regulatory_conditions_met","pari_passu_conditions_met","notice_and_payment_date_met","issuer_elected_write_up"]


def up(conditions):
    return m.write_up(annual_profit="100",written_down_initial="200",tier1="1000",distributions="5",mda_available="12",own_initial="100",pool_initial="200",own_prevailing="90",issuer_selected_total="100",conditions=conditions,premise_kind="HYPOTHETICAL")


def test_write_up_cap_is_not_an_entitlement():
    out=up(dict.fromkeys(CONDITIONS,True))
    assert out["H"]=="20" and out["available_pool_cap"]=="12" and out["write_up"]=="6"
    assert out["entitlement_from_cap"] is False and out["actual_write_up"]=="NOT_ESTABLISHED"


@pytest.mark.parametrize("condition",CONDITIONS)
def test_each_write_up_condition_can_veto(condition):
    conditions=dict.fromkeys(CONDITIONS,True);conditions[condition]=False
    assert up(conditions)["write_up"]=="0"
    del conditions[condition]
    with pytest.raises(ValueError):up(conditions)


def test_metadata_repair_preserves_source_selection_and_is_idempotent():
    old={"documents":{"d":{"sha256":"abc"}},"issues":[{"id":"senior","security_type":"debt"}],"scope":"30 old issues"}
    snapshot=deepcopy(old);new=m.repaired_inventory(old)
    assert old==snapshot and new["documents"]==old["documents"] and new["issues"]==old["issues"]
    assert "1 exposed" in new["scope"] and new==m.repaired_inventory(new)
    bank={"context":{"instrument_kind":"at1_bond","instrument_id":"wrong","facts_sha256":"unchanged"}}
    repaired=m.issue_context(bank,old["issues"][0])
    assert repaired["context"]["instrument_kind"]=="debt_bond" and repaired["context"]["facts_sha256"]=="unchanged"
    assert bank["context"]["instrument_id"]=="wrong"


@pytest.mark.parametrize("url",["http://www.enel.com/x","https://localhost/x","https://www.enel.com.evil/x","https://user@www.enel.com/x","https://www.enel.com:444/x","file:///tmp/file"])
def test_acquisition_host_and_scheme_are_bounded(url):
    with pytest.raises(ValueError):s.valid_url(url,{"public_hosts":["www.enel.com"]})


def setup_control(tmp_path,monkeypatch):
    root=tmp_path;out=root/"out";data=root/"data"
    monkeypatch.setattr(c,"ROOT",root);monkeypatch.setattr(c,"OUT",out);monkeypatch.setattr(c,"DATA",data)
    monkeypatch.setattr(c,"PLAN",root/"plan.md")
    (root/"plan.md").write_text("plan")
    c.write(root/"docs/prospectus/gap-closure/final-inventory.json",{"issues":[]})
    c.write(out/"allowlist.json",{"max_execution_seconds":100,"max_failures_per_input":3})
    monkeypatch.setattr(c,"method_files",lambda:{"fixed":"method"})
    monkeypatch.setattr(c.subprocess,"check_output",lambda *a,**k:"git-head\n")
    return root,out,data


def test_real_phase_failure_then_repair_retains_attempts_and_refreshes(tmp_path,monkeypatch):
    from legalmath.prospectus import master_phases
    root,out,data=setup_control(tmp_path,monkeypatch)
    def broken(*args):raise ValueError("constructed defect")
    monkeypatch.setattr(master_phases,"execute",broken)
    state=c.state();first=c.run_phase("E0",state)
    assert first["status"]=="FAILED" and c.read(out/"next-phase-plan.json")["next_phase"]=="E0"
    monkeypatch.setattr(master_phases,"execute",lambda *args:{"status":"PASS","repairs":["fixed constructed defect"],"open_issues":[]})
    second=c.run_phase("E0",state)
    assert second["status"]=="PASS" and second["directory"]!=first["directory"]
    assert c.read(out/"next-phase-plan.json")["next_phase"]=="E1"
    assert (root/first["directory"]/"result.json").exists()
    assert c.run_phase("E0",state)==second
    assert len(list((out/"phases/E0").glob('attempt-*')))==2
    (root/second["directory"]/"result.json").write_text("tamper")
    assert not c.current_phase("E0",state)


def test_interruption_is_preserved_and_resume_does_not_claim_success(tmp_path,monkeypatch):
    root,out,data=setup_control(tmp_path,monkeypatch)
    attempt=out/"phases/E0/attempt-001";attempt.mkdir(parents=True)
    state=c.state();state["phases"]["E0"]={"status":"RUNNING","directory":str(attempt.relative_to(root))}
    c.recover_interruption(state)
    assert state["phases"]["E0"]["status"]=="INTERRUPTED"
    assert (attempt/"interruption.json").exists() and not c.current_phase("E0",state)


def test_method_and_input_changes_invalidate_completion(tmp_path,monkeypatch):
    from legalmath.prospectus import master_phases
    root,out,data=setup_control(tmp_path,monkeypatch)
    monkeypatch.setattr(master_phases,"execute",lambda *args:{"status":"PASS","open_issues":[]})
    state=c.state();c.run_phase("E0",state)
    assert c.current_phase("E0",state)
    monkeypatch.setattr(c,"method_files",lambda:{"fixed":"changed"})
    assert not c.current_phase("E0",state)


def test_missing_private_inputs_never_become_permission():
    r=m.input_requirements({"id":"unknown"},[{}])
    assert r["calculation_profile"]=="NOT_IMPLEMENTED" and not r["may_execute_transaction"] and not r["actual_inputs_supplied"]


def test_campaign_paths_reject_escape(tmp_path,monkeypatch):
    root,out,data=setup_control(tmp_path,monkeypatch)
    with pytest.raises(ValueError):c.campaign_path("/etc/passwd")
    with pytest.raises(ValueError):c.campaign_path("data/../../outside")
    assert c.campaign_path("data/selection.json")==data/"selection.json"

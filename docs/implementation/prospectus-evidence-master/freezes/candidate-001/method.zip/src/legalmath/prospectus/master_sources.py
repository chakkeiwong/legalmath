"""Bounded public retrieval and sealed issue registration, never legal clearance."""
from datetime import datetime
from html.parser import HTMLParser
import re
import subprocess
import time
from urllib.parse import urlparse, urljoin

from .master_control import ROOT, OUT, DATA, read, write, sha, now, relative, digest, method_files, campaign_path


class Links(HTMLParser):
    def __init__(self):
        super().__init__(); self.links=[];self.parts=[];self.anchor=None;self.skip=0
    def handle_starttag(self,tag,attrs):
        if tag in ("script","style"):self.skip+=1
        if tag=="a":self.anchor={"href":dict(attrs).get("href",""),"text":""}
    def handle_endtag(self,tag):
        if tag in ("script","style"):self.skip=max(0,self.skip-1)
        if tag=="a" and self.anchor:self.links.append(self.anchor);self.anchor=None
    def handle_data(self,data):
        if not self.skip:self.parts.append(data)
        if self.anchor:self.anchor["text"]+=data


def valid_url(url,policy):
    parsed=urlparse(url)
    if parsed.scheme!="https" or parsed.hostname not in policy["public_hosts"] or parsed.username or parsed.password or parsed.port not in (None,443):
        raise ValueError("Only approved HTTPS public source hosts are accepted")
    return url


def acquire(key,url,purpose,current):
    policy=read(OUT/"allowlist.json")
    valid_url(url,policy)
    if not re.fullmatch(r"[a-z0-9-]{1,80}",key) or purpose not in {"contract","authority","corporate","capital","discovery"}:raise ValueError("Invalid source key or purpose")
    if "freeze" not in current:raise ValueError("Freeze before public-source inspection")
    previous=sorted((DATA/"requests").glob("*/receipt.json"))
    if len(previous)>=policy["max_http_requests"]:raise ValueError("80-request protocol budget exhausted")
    if sum(read(p)["url"]==url for p in previous)>=policy["max_requests_per_url"]:raise ValueError("Per-URL retry budget exhausted")
    directory=DATA/"requests"/f"{len(previous)+1:03d}-{key}"
    directory.mkdir(parents=True,exist_ok=False)
    receipt={"at":now(),"key":key,"url":url,"purpose":purpose,"status":"DISPATCH_RESERVED","freeze":current["freeze"],
             "original":relative(directory/"response.body"),"budget_sequence":len(previous)+1}
    write(directory/"receipt.json",receipt)
    # Redirects are recorded and followed explicitly so every HTTP request is
    # budgeted and each destination host is validated before dispatch.
    command=["curl","--max-time",str(policy["max_http_seconds"]),"--connect-timeout","15","--max-filesize",str(policy["max_response_bytes"]),
             "--proto","=https","-A","LegalMath public-source research","-sS","-D",str(directory/"headers.txt"),
             "-o",str(directory/"response.body"),"-w","%{http_code}",url]
    started=time.monotonic()
    try:
        p=subprocess.run(command,capture_output=True,timeout=policy["max_http_seconds"]+5)
        (directory/"stderr.log").write_bytes(p.stderr)
        code=int(p.stdout.strip()) if p.stdout.strip().isdigit() else 0
        receipt.update(exit_code=p.returncode,http_status=code,status="RETAINED" if code==200 and p.returncode==0 else "FAILED_OR_REDIRECT")
    except subprocess.TimeoutExpired as exc:
        (directory/"stderr.log").write_bytes(exc.stderr or b"")
        receipt.update(exit_code=124,http_status=0,status="TIMEOUT")
    path=directory/"response.body"
    if not path.exists():path.write_bytes(b"")
    receipt.update(command=command,sha256=sha(path),bytes=path.stat().st_size,wall_seconds=time.monotonic()-started)
    raw=path.read_bytes()
    receipt["kind"]="pdf" if raw.startswith(b"%PDF") else "html_or_other"
    headers=(directory/"headers.txt").read_text(errors="replace") if (directory/"headers.txt").exists() else ""
    location=re.findall(r"(?im)^location:\s*(.*?)\s*$",headers)
    if location:receipt["redirect"]=urljoin(url,location[-1])
    if receipt["status"]=="RETAINED" and receipt["kind"]!="pdf":
        parser=Links();parser.feed(raw.decode(errors="replace"))
        write(directory/"links.json",[{"url":urljoin(url,x["href"]),"text":" ".join(x["text"].split())} for x in parser.links])
        (directory/"text.txt").write_text("\n".join(parser.parts))
    write(directory/"receipt.json",receipt)
    return receipt


def extract(receipt_path):
    receipt=read(receipt_path);original=ROOT/receipt["original"]
    if receipt["status"]!="RETAINED" or sha(original)!=receipt["sha256"]:raise ValueError("Source unavailable or changed")
    target=DATA/"extractions"/receipt["sha256"]
    path=target/"pages.json"
    if path.exists():
        data=read(path)
        if data["source_sha256"]!=receipt["sha256"]:raise ValueError("Extraction source identity changed")
        return path
    target.mkdir(parents=True,exist_ok=True)
    repairs=[]
    if receipt["kind"]=="pdf":
        from pypdf import PdfReader
        try:
            pages=[{"page":i+1,"text":p.extract_text() or ""} for i,p in enumerate(PdfReader(original).pages)]
            if not pages or sum(len(p["text"].strip()) for p in pages)<100:raise ValueError("Insufficient extracted text")
        except Exception as exc:
            write(target/"pypdf-failure.json",{"error":repr(exc)},exclusive=True)
            result=subprocess.run(["pdftotext","-layout",str(original),str(target/"poppler.txt")],capture_output=True,timeout=60)
            (target/"poppler.log").write_bytes(result.stdout+result.stderr)
            if result.returncode:raise ValueError("Both extraction engines failed")
            text=(target/"poppler.txt").read_text();parts=text.split("\f")
            if not parts[-1].strip():parts.pop()
            pages=[{"page":i+1,"text":t} for i,t in enumerate(parts)]
            if sum(len(p["text"].strip()) for p in pages)<100:raise ValueError("OCR required; no text evidence")
            repairs.append("Executed Poppler fallback after retained pypdf failure")
    else:
        parser=Links();parser.feed(original.read_text(errors="replace"))
        pages=[{"page":1,"text":" ".join(parser.parts)}]
    write(path,{"id":receipt["key"],"source_sha256":receipt["sha256"],"pages":pages,"preliminary_indicator":False,
                "extraction":"pypdf with bounded Poppler fallback; no English equivalence claim","repairs":repairs},exclusive=True)
    return path


def register(selection_path,current):
    selection=read(selection_path)
    frozen=read(ROOT/current["freeze"])
    if frozen["files"]!=method_files():raise ValueError("Method changed since freeze; rerun development validation")
    issues=selection["issues"]
    if not issues and not selection.get("acquisition_exhausted"):raise ValueError("No selected issues or recorded exhausted acquisition")
    documents={};families=set(); categories={"capital":0,"corporate":0}
    exposed_sources=set(frozen["source_requests_before_freeze"])
    for src in selection.get("sources",[]):
        receipt_path=campaign_path(src["receipt"]);receipt=read(receipt_path)
        if receipt["kind"]!="pdf":raise ValueError("New issue selections require retained PDF originals")
        path=extract(receipt_path);text=read(path)
        if not src.get("identity_markers"):raise ValueError("Issue identity markers required")
        alltext=" ".join(" ".join(p["text"].split()) for p in text["pages"])
        if any(marker not in alltext for marker in src["identity_markers"]):raise ValueError("Source identity marker missing")
        documents[src["id"]]={"id":src["id"],"original":receipt["original"],"sha256":receipt["sha256"],"text":relative(path),
                               "text_sha256":sha(path),"pages":len(text["pages"]),"url":receipt["url"],"identity_markers":src["identity_markers"],
                               "acquisition_receipt":relative(receipt_path)}
    old_issues=read(ROOT/"docs/prospectus/gap-closure/final-inventory.json")["issues"]
    old_ids={i["id"] for i in old_issues};old_identifiers={v for i in old_issues for v in i["identifiers"]}
    for issue in issues:
        if {"answer","expected_answer","expected_answers","quality"}&set(issue):raise ValueError("No answer or quality labels")
        if issue["id"] in old_ids or set(issue["identifiers"])&old_identifiers:raise ValueError("Existing issue cannot be called unseen")
        if issue["category"] not in categories:raise ValueError("Unknown category")
        if issue["family"] not in read(OUT/"allowlist.json")["source_family_order"][issue["category"]]:raise ValueError("Undeclared family")
        if issue["family"] in families:raise ValueError("Use distinct families for the challenge")
        families.add(issue["family"]);categories[issue["category"]]+=1
        if not issue.get("selection_basis"):raise ValueError("Source-based selection reason required")
        for s in issue["documents"]:
            if s["id"] not in documents:raise ValueError("Missing selected source")
            if not s.get("scope_basis"):raise ValueError("Document scope must be explained before classification")
        issue["data_role"]="exposed-after-repair" if any(documents[s["id"]]["acquisition_receipt"] in exposed_sources for s in issue["documents"]) else "fresh-family-frozen-challenge"
    directory=DATA/"registrations"/f"selection-{len(list((DATA/'registrations').glob('selection-*')))+1:03d}"
    directory.mkdir(parents=True)
    inventory={"documents":documents,"issues":issues,"freeze":current["freeze"],"scope":"Selected dated issue documents; full contracts and actual bank permission remain unestablished."}
    write(directory/"inventory.json",inventory,exclusive=True)
    write(directory/"registration.json",{"at":now(),"selection_sha256":sha(selection_path),"freeze_sha256":sha(ROOT/current["freeze"]),
          "inventory_sha256":sha(directory/"inventory.json"),"categories":categories,"classified_before_selection":False},exclusive=True)
    write(DATA/"registered.json",{"inventory":relative(directory/"inventory.json"),"sha256":sha(directory/"inventory.json"),"selection_sha256":sha(selection_path)})
    return {"status":"REGISTERED","inventory":relative(directory/"inventory.json"),"categories":categories}

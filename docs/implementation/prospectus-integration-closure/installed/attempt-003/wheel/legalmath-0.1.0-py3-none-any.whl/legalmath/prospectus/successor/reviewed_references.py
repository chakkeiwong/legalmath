"""Explicit source-reviewed references beyond the bounded heading recognizer."""
from .admissions import review
from .anchors import fields, bind
from .contracts import digest
from .occurrences import uses, target


def admit(graph, assembly, packet):
    fields(packet, {'version','assembly_sha256','review','references'},
           {'version','assembly_sha256','review','references'})
    if packet['version'] != 'reviewed-references.v1' or packet['assembly_sha256'] != digest(assembly):
        raise ValueError('Reviewed reference assembly changed')
    review(packet['review'])
    selected = {u['unit']:u for u in assembly['units']}
    raw = {u['id']:u for u in graph['units']}
    ids, dependencies, edges = set(), [], []
    for row in packet['references']:
        fields(row, {'id','form','source','from_use','language','targets','authority','questions','reason'},
               {'id','form','source','from_use','language','targets','authority','questions','reason'})
        if (not row['id'] or row['id'] in ids or row['form'] not in {'named','relative','external','amendment'} or
                not row['reason'] or not row['questions'] or set(row['questions']) - {'Q1','Q2'}):
            raise ValueError('Invalid reviewed reference')
        ids.add(row['id'])
        bind(graph,row['source'])
        if raw[row['source']['unit']]['language'] != row['language']:
            raise ValueError('Reference language differs from source')
        if not row['targets']:
            raise ValueError('Reviewed reference needs exact targets')
        destinations = []
        for value in row['targets']:
            fields(value, {'source','use','language'}, {'source','use','language'})
            found = target(graph, assembly, {k:value[k] for k in ('source','use')})
            if (raw[value['source']['unit']]['language'] != value['language'] or
                    selected[found['unit']]['role'] != 'OPERATIVE' or
                    not set(row['questions']) <= set(selected[found['unit']]['questions'])):
                raise ValueError('Reference target is not operative in the declared language/question')
            if row['form']=='external' and value['source']['document']==row['source']['document']:
                raise ValueError('External reference requires another document')
            destinations.append(found)
        for question in row['questions']:
            referring = [m for m in uses(graph,assembly,row['source'],question=question) if m['unit']==row['from_use']]
            if len(referring)!=1 or len(uses(graph,assembly,row['authority'],question=question))!=1:
                raise ValueError('Reference source/authority is not an unambiguous selected occurrence')
        identity = 'reviewed-reference:'+row['id']
        dependencies.append({'id':identity,'questions':row['questions'],'status':'RESOLVED',
            'source_use':referring[0],'targets':destinations,'form':row['form'],
            'authority':row['authority'],'review':packet['review'],'automatic_discovery':False})
        for destination in destinations:
            edges.append({'id':identity,'from':row['from_use'],'to':destination['unit'],
                'kind':'reference','resolved':True,'authority':row['authority']})
    return dependencies, edges

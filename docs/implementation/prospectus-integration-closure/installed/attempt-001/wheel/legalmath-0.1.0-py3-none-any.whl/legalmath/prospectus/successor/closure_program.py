"""Isolated closure attempts; valid evidence is distinct from criterion success."""
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import importlib.metadata
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from .contracts import digest, read, write

REL = "docs/implementation/prospectus-integration-closure"
PLAN = "docs/plans/prospectus-integration-closure-2026-10-08.md"
DAG = {"R0": [], "R1": ["R0"], "R2": ["R1"], "R3": ["R1"],
       "R4": ["R2", "R3"], "R5": ["R4"], "R6": ["R5"], "R7": ["R6"],
       "R8": ["R1", "R2", "R3", "R4", "R5", "R6", "R7"]}
JOBS = {
    "R0": ("tests/prospectus_successor/test_closure_program.py", None),
    "R1": ("tests/prospectus_successor/test_integration_closure.py", "not solver and not z3"),
    "R2": ("tests/prospectus_successor/test_integration_closure.py", "solver or z3"),
    "R3": ("tests/prospectus_successor/test_closure_consumers.py", "layout or poppler"),
    "R4": ("tests/prospectus_successor/test_closure_consumers.py tests/prospectus_successor/test_closure_reviews.py", "annotation or relation or disposition or review_record or evaluation"),
    "R5": ("tests/prospectus_successor/test_closure_consumers.py", "finance"),
    "R6": ("tests/prospectus_successor/test_closure_runtime.py tests/prospectus_successor/test_closure_consumers.py", "runtime or current_consume or missing_poppler"),
    "R7": ("tests/prospectus_successor/test_closure_reviews.py", "review_record or evaluation"),
    "R8": ("tests/prospectus_successor/test_closure_attribution.py", None),
}


def command(*args):
    return ["python3", "-m", "scripts.prospectus_delivery", "--program", "closure", *args]


def bindings(root, phase):
    root = Path(root)
    paths = list((root / "src/legalmath/prospectus/successor").glob("*.py"))
    paths += [root / p for p in ("scripts/prospectus_delivery.py", "src/legalmath/cli.py", "pyproject.toml", PLAN)]
    paths += list((root / "tests/prospectus_successor").glob("*.py"))
    paths += list((root / REL / "inputs" / phase).rglob("*"))
    packages = {name: importlib.metadata.version(name) for name in ("legalmath", "pytest", "hypothesis", "z3-solver")}
    return {"files": {str(p.relative_to(root)): digest(p.read_bytes()) for p in sorted(set(paths)) if p.is_file()},
            "environment": {"python": sys.version, "packages": packages, "mode": "CPU", "CUDA_VISIBLE_DEVICES": "-1",
                            "checkout_test_source": str(root / "src")}}


def preflight(root):
    return {"version": "closure-preflight.v1", "python": sys.executable,
            "cpu_gpu": "CPU; GPU intentionally hidden before imports", "gpu_probed": False,
            "executables": {name: shutil.which(name) for name in ("pdftotext", "pdfinfo", "java")},
            "runtime_paths": {str(p): p.exists() for p in (
                Path("/tmp/prospectus-adoption-tools/bin/python"), Path("/tmp/prospectus-adoption-models"))},
            "implemented_phases": sorted(JOBS), "plan": PLAN,
            "external_acceptance": "NOT_ESTABLISHED"}


def verified_attempt(root, folder):
    """A sealed receipt is the commit point; interrupted outputs remain evidence."""
    path = folder / "receipt.json"
    if not path.is_file():
        return None
    try:
        receipt = read(path)
        body = {k: v for k, v in receipt.items() if k != "sha256"}
        if receipt.get("sha256") != digest(body):
            return None
        actual = {p.name for p in folder.iterdir() if p.is_file() and p.name != "receipt.json"}
        if actual != set(receipt["outputs"]):
            return None
        for name, sha in receipt["outputs"].items():
            if Path(name).name != name or digest((folder / name).read_bytes()) != sha:
                return None
        return {**receipt, "directory": str(folder.relative_to(root))}
    except (KeyError, TypeError, ValueError, OSError):
        return None


def status(root):
    root = Path(root)
    rows = {}
    for phase, parents in DAG.items():
        attempts = [verified_attempt(root, p) for p in sorted((root / REL / "phases" / phase).glob("attempt-*"))]
        valid = [row for row in attempts if row]
        latest = valid[-1] if valid else None
        current = bool(latest and latest["method"] == digest(bindings(root, phase)) and all(
            rows[p]["current"] and latest["parents"].get(p) == rows[p]["receipt_sha256"] for p in parents))
        ready = phase in JOBS and all(rows[p]["current"] and rows[p]["engineering_checks"] == "PASS" for p in parents)
        rows[phase] = {"phase": phase, "handler_exists": phase in JOBS, "current": current,
            "artifact_valid": bool(latest), "execution": latest["execution"] if latest else "NOT_EXECUTED",
            "engineering_checks": latest["engineering_checks"] if latest else "NOT_CHECKED",
            "primary_criterion": latest["primary_criterion"] if latest else "NOT_CHECKED",
            "consumer_integration": latest["consumer_integration"] if latest else "NOT_CHECKED",
            "external_acceptance": "NOT_ESTABLISHED", "can_dispatch": ready,
            "receipt_sha256": latest["sha256"] if latest else None,
            "directory": latest["directory"] if latest else None,
            "remaining": latest.get("remaining", []) if latest else ["Implement and validate the phase handler"],
            "command": command("phase", "--phase", phase)}
    return {"version": "closure-status.v1", "phases": list(rows.values()), "automatic_release": False}


@contextmanager
def lock(root):
    folder = Path(root) / REL
    folder.mkdir(parents=True, exist_ok=True)
    with (folder / "controller.lock").open("a") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield


def _refresh(root):
    result = status(root)
    result["next_command"] = next((r["command"] for r in result["phases"]
        if r["can_dispatch"] and not r["current"]), None)
    result["review"] = "Failed criteria require a changed repair; valid partial evidence may feed a reviewed path."
    write(Path(root) / REL / "next-phase.json", result)
    return result


def refresh(root):
    with lock(root):
        return _refresh(Path(root))


def execute(root, phase):
    root = Path(root)
    if phase not in DAG:
        raise ValueError("Unknown closure phase")
    with lock(root):
        before = status(root)
        row = next(r for r in before["phases"] if r["phase"] == phase)
        if row["current"] and row["engineering_checks"] == "PASS":
            return {**row, "reused": True}
        if not row["can_dispatch"]:
            return {**row, "execution": "HANDLER_OR_DEPENDENCY_MISSING"}
        method_inputs = bindings(root, phase)
        method = digest(method_inputs)
        base = root / REL / "phases" / phase
        previous = sorted(base.glob("attempt-*"))
        identical = [p for p in previous if (p / "started.json").exists() and read(p / "started.json")["method"] == method]
        if identical:
            raise ValueError("Unchanged failed/interrupted input requires a recorded repair before retry")
        folder = base / f"attempt-{len(previous)+1:03d}"
        folder.mkdir(parents=True)
        started = time.monotonic()
        parents = {r["phase"]: r["receipt_sha256"] for r in before["phases"] if r["phase"] in DAG[phase]}
        test_paths = JOBS[phase][0].split()
        argv = [sys.executable, "-m", "pytest", "-q", *test_paths, "--junitxml=" + str(folder / "tests.xml")]
        if JOBS[phase][1]:
            argv += ["-k", JOBS[phase][1]]
        record = {"phase": phase, "method": method, "bindings": method_inputs, "parents": parents,
                  "argv": argv, "plan": PLAN, "started_at": datetime.now(timezone.utc).isoformat(),
                  "git_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
                  "cpu_gpu": "CPU; CUDA_VISIBLE_DEVICES=-1", "random_seeds": "Deterministic fixtures; Hypothesis stores counterexamples"}
        write(folder / "started.json", record)
        try:
            run = subprocess.run(argv, cwd=root, env={**os.environ, "CUDA_VISIBLE_DEVICES": "-1",
                                 "PYTHONPATH": str(root / "src") + os.pathsep + str(root)},
                                 capture_output=True, timeout=600)
            (folder / "command.log").write_bytes(run.stdout + run.stderr)
            suites = ET.parse(folder / "tests.xml").getroot()
            counts = {k: sum(int(s.get(k, 0)) for s in suites.iter("testsuite")) for k in ("tests", "failures", "errors", "skipped")}
            passed = run.returncode == 0 and counts["tests"] > 0 and not any(counts[k] for k in ("failures", "errors", "skipped"))
            if digest(bindings(root, phase)) != method:
                raise ValueError("Method or inputs changed during phase")
            pending = [] if phase == "R0" else ["Installed workflow and broader phase obligations remain for R6/final review"]
            result = {"execution": "COMPLETED" if run.returncode == 0 else "FAILED", "test_counts": counts,
                      "engineering_checks": "PASS" if passed else "FAIL",
                      "primary_criterion": ("PARTIAL" if pending else "PASS") if passed else "FAIL",
                      "consumer_integration": "SERVICE_TESTED" if passed and phase != "R0" else "NOT_APPLICABLE",
                      "remaining": pending if passed else ["Repair the failing checks before repeating this phase"]}
        except Exception as exc:
            result = {"execution": "FAILED", "engineering_checks": "FAIL", "primary_criterion": "INVALID_RUN",
                      "consumer_integration": "NOT_CHECKED", "remaining": [type(exc).__name__ + ": " + str(exc)]}
        result.update(phase=phase, wall_seconds=time.monotonic() - started, external_acceptance="NOT_ESTABLISHED")
        write(folder / "result.json", result)
        receipt = {**result, "method": method, "parents": parents,
                   "outputs": {p.name: digest(p.read_bytes()) for p in folder.iterdir() if p.is_file()}}
        write(folder / "receipt.json", {**receipt, "sha256": digest(receipt)})
        _refresh(root)
        return {**result, "directory": str(folder.relative_to(root)), "reused": False}

"""Selected-occurrence term admission; finance consumes P3's checked values."""
from copy import deepcopy
from decimal import Decimal, InvalidOperation
from datetime import date
from .anchors import fields
from .contracts import digest
from .occurrences import uses
from .admissions import review

REQUIRED = {"currency", "annual_rate", "day_count", "frequency", "eom", "adjustment", "rounding"}


def admit(graph, assembly, packet):
    fields(packet, {"version", "assembly_sha256", "review", "terms"},
           {"version", "assembly_sha256", "review", "terms"})
    if packet["version"] != "selected-coupon-terms.v1" or packet["assembly_sha256"] != digest(assembly):
        raise ValueError("Contract term assembly changed")
    review(packet["review"])
    if set(packet["terms"]) != REQUIRED:
        raise ValueError("Complete named coupon term set required")
    terms = {}
    for name, row in packet["terms"].items():
        fields(row, {"value", "source", "use", "rule", "reason"}, {"value", "source", "use", "rule", "reason"})
        matches = [m for m in uses(graph, assembly, row["source"]) if m["unit"] == row["use"]]
        if len(matches) != 1 or not row["reason"]:
            raise ValueError("Contract term requires an operative selected occurrence")
        text = row["source"]["quote"].strip()
        rule = row["rule"]
        try:
            if rule == "percent":
                if not text.endswith("%") or name != "annual_rate":
                    raise ValueError("Percent rate quotation required")
                if Decimal(text[:-1].strip()) / 100 != Decimal(row["value"]):
                    raise ValueError("Rate differs from selected percentage")
            elif rule == "literal":
                if row["value"] != text:
                    raise ValueError("Term differs from its literal quotation")
            elif rule == "integer":
                if type(row["value"]) is not int or str(row["value"]) != text:
                    raise ValueError("Integer term differs from its quotation")
            elif rule != "reviewed-convention" or name in {"annual_rate", "currency", "frequency"}:
                raise ValueError("Unsupported deterministic term translation")
        except (InvalidOperation, TypeError) as exc:
            raise ValueError("Invalid term representation") from exc
        terms[name] = {**row, "selected_use": matches[0]}
    return {"version": "admitted-coupon-terms.v1", "assembly_sha256": digest(assembly),
            "graph_sha256": digest(graph), "terms": terms, "review": packet["review"],
            "qualification": "CONDITIONAL_ON_SUPPLIED_CONVENTION_INTERPRETATIONS"}


def scenario(admitted, calculation, graph, assembly):
    from .fixed_coupon import calculate
    fields(calculation, {"version", "terms_sha256", "premises"}, {"version", "terms_sha256", "premises"})
    if (calculation["version"] != "selected-coupon-calculation.v1" or calculation["terms_sha256"] != digest(admitted) or
            admitted["assembly_sha256"] != digest(assembly) or admitted["graph_sha256"] != digest(graph)):
        raise ValueError("Selected contract terms or calculation binding changed")
    value = deepcopy(calculation["premises"])
    if REQUIRED & set(value):
        raise ValueError("Calculation premises cannot replace selected contract terms")
    if value.get("premise_kind") != "HYPOTHETICAL":
        raise ValueError("Actual entitlement/event validation is not established by this calculation")
    for key, term in admitted["terms"].items():
        value[key] = term["value"]
        value.setdefault("evidence", {})[key] = {"source": term["source"], "reason": term["reason"]}
    output = calculate(value, graph)
    return {"calculation": output, "selected_terms_sha256": digest(admitted),
            "contract_terms": admitted, "fact_scope": "HYPOTHETICAL_ENTITLEMENT_AND_EVENTS",
            "full_settlement_supported": False}

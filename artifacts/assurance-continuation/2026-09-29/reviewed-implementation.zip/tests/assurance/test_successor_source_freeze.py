"""Both study arms must receive the same complete selected source set."""
from pathlib import Path
import sys
import pytest
from legalmath.canonical import digest
from legalmath.errors import LegalMathError

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
from assurance_successor_sources import prepare,read_source
from run_assurance_successor import read,OUT


def test_retained_authentication_appendix_is_an_explicit_root_for_both_arms():
    tasks=[read(ROOT/r['path']) for r in read(OUT/'task-freeze.json')['tasks']]
    prepared=prepare(ROOT,OUT,tasks)
    auth=prepared['26ec35'];original=next(t for t in tasks if t['task_id']=='26ec35')
    assert len(auth['sources'])==2
    assert len(auth['task']['packet']['units'])>len(original['packet']['units'])
    selected={u['unit_id']:u['text'] for u in auth['task']['packet']['units']}
    assert all(selected[u['unit_id']]==u['text'] for u in original['packet']['units'])
    assert all(u['text']==selected[u['unit_id']] for u in original['packet']['units'])
    for case in read(OUT/'conditional-case-reference.json')['cases']:
        units={u['unit_id']:u['text'] for u in prepared[case['task_id']]['task']['packet']['units']}
        assert all(q['quote'] in units[q['unit_id']] for q in case['evidence'])


def test_changed_source_is_rejected_before_it_can_enter_either_arm(tmp_path):
    p=tmp_path/'source.txt';p.write_text('original')
    from legalmath.canonical import raw_digest
    ref={'path':'source.txt','sha256':raw_digest(p.read_bytes()),'url':'https://apps.sfc.hk/example','media_type':'text/plain'}
    p.write_text('changed')
    with pytest.raises(LegalMathError):read_source(tmp_path,ref)


def test_compact_v2_preserves_document_identity_and_exact_source_content():
    from legalmath.interpretation.assurance.decomposition import compact_request
    row=read(OUT/'study-source-freeze.json')['tasks'][-1]
    request={'source_packet':row['packet']}
    legacy=compact_request(request,profile='v1');current=compact_request(request,profile='v2')
    assert 'source_packet_document_locators' not in legacy
    assert len(current['source_packet_document_locators'])==2
    assert compact_request(current,profile='v2')==current
    fields=lambda v:[(u['unit_id'],u['text'],u['normative']) for u in v['source_packet']['units']]
    assert fields(request)==fields(current)==fields(legacy)
    expected={u['locator'].rsplit(' chars ',1)[0] for u in row['packet']['units']}
    actual={url for urls in current['source_packet_document_locators'].values() for url in urls}
    assert expected==actual


@pytest.mark.parametrize('profile',['v1','v2'])
def test_historical_and_current_transport_receipts_reconstruct_their_own_bytes(tmp_path,profile):
    from legalmath.canonical import canonical
    from legalmath.interpretation.assurance.decomposition import compact_request
    from legalmath.interpretation.assurance.checkpoints import receipt,verify_receipt
    packet=read(OUT/'study-source-freeze.json')['tasks'][0]['packet']
    request={'task':'SOURCE_INVENTORY','source_packet':packet};wire=compact_request(request,profile=profile)
    ledger=tmp_path/'ledger.json';ledger.write_bytes(canonical({'maximum':1,
        'calls':[{'request_hash':digest(wire),'issued_at_ns':'1'}]}))
    response={'value':{'synthetic_only':True},'provenance':{'allowance_slot':1,
        'request_hash':digest(wire),'provider_route_hash':'a'*64,'original_request_hash':digest(request),
        'wire_request_hash':digest(wire),'compact_request':wire,'transport_profile':'exact-source-text.compact.'+profile}}
    value=receipt(request,response,ledger,'a'*64)
    verify_receipt(value,request,response,'a'*64)

# Additional allowance: interpretation continuation and whole-method observations

29 September 2026. User authorization: **“you have another 500 calls. continue”**.
This is a new, nonrefundable ceiling of 500 fresh model requests. Both exhausted
500-call predecessors remain immutable. Failed and timed-out requests consume
the allowance. This plan does not reset earlier issue, arm or phase limits.

## Question and evidence contract

Can the repaired executable-span and readable-table transports support actual
source investigations, while preserving every earlier unsuccessful attempt?
Can a future-source observation be checked against the entire frozen method,
rather than only the final proof checker?

The baselines are the retained UCITS 25EC66 investigation (225 pairs, 60 without
two validated perspectives), the four-task unfamiliar-source study, and D1's
synthetic full-source readable-table check. D1 is a byte-preservation baseline,
not evidence that a live model understands the tables. All sources already seen
are development data; nothing here converts them into prospective observations.

Pass criteria are exact accounting and independently checked identities:
original issues cannot receive excess requests; selected IDs resolve to the
unchanged original source/program text; rejected responses remain rejected;
all required pairs/units/questions and unresolved concerns remain in reports.
A whole-investigation observation must bind source acquisition/extraction,
provider route, search settings, question/authority/scoped stages, transports,
issue limits, implementation and qualification evidence to the frozen method.
Native/proof checks are executed when an observation makes those claims.

Integrity failure, changed source bytes, unavailable authenticated provider,
or an invalid harness veto continuation of the affected command. Exhaustion,
invalid model answers, ambiguity, unsupported programs and disagreement qualify
the candidate and trigger the next eligible repair/work item; they do not
invalidate the research direction. No result establishes English interpretation,
legal accuracy, model independence, statistical superiority or future legal
generalization. No human labels or quality approvals enter the experiment.

## Executable phases and spending

1. **F0: grant and eligibility.** Freeze predecessor hashes and every original
   arm balance. Reconstruct actual issue reservations from retained provider
   requests, including failures. Canonical issue identities must survive the
   added executable `reading_hash` field and transport changes. Report expired
   deadlines separately from missing/unattempted perspectives.
2. **F1: bounded continuation.** Add and test a cross-grant allowance that carries
   old arm spending without rewriting the old slice. Live UCITS work can consume
   at most its remaining 28 arm calls, and only on original eligible issues.
   Begin with one complete batch/two perspectives; preserve both blind first
   responses. Review actual response diagnostics before breadth-first remaining
   batches and bounded follow-ups. Use executable-spans v2, unchanged validators,
   200,000 input/output bytes and 300-second requests.
3. **F2: readable-input and revised-source work.** Test readable tables with fresh
   model calls on retained coverage inputs (at most 12 diagnostic requests),
   explicitly separate from a historical arm's legal judgments. A test of a
   synthetic coverage input remains a transport test. Inventory incomplete
   eDDA/authentication issues and the acquired 23EC52 appendix; run only eligible
   original issues or explicitly identified new source-revision questions.
   Allocate at most 60 requests to each of these three source work items, with
   a two-request pilot and at most three attempts per issue. No source revision
   may erase unresolved predecessor questions. The private-market historical
   ensemble remains exhausted at 120/120.
4. **F3: whole-method joining contract.** Implement a separate future-observation
   API that accepts actual retained investigation dossiers, not supplied grades.
   Bind the full method before selection; check the actual stage records and
   every candidate's qualification. Test stale methods, missing stages, source
   substitution, duplicate observations and repaired-window exclusion. Preserve
   pending/incomplete observations, and keep the existing qualification-only
   window explicitly component-scoped. A new future window requires the final
   method freeze and later publication/encounter dates.
5. **F4: verification and refreshed successor.** Run focused regressions after
   each repair, then the affected integration suite and one full suite on an
   isolated final snapshot. Update results, reset memo and unified monograph
   with actual counts, remaining qualifications and a concrete next-phase plan.
   Build and inspect changed PDF pages; retain prior substantive content.

The initial live allocation is at most 220 calls (28 + 12 + 3×60). The remaining
280 are reserved. Reallocation needs a recorded phase review with a specific
new question and limits; it is not automatic repetition. The overall controller
must reject requests above 500 regardless of local allocation. Each phase has
at most three engineering attempts. A retry requires a causal repair note and
an executed focused check. Each terminal phase writes a refreshed next action.

## Default audit and pre-mortem

| Choice | Provenance / justification | Failure / early check | Status |
|---|---|---|---|
| 500 calls | This user message | Silent reuse of old grant; verify predecessor hashes and new ledger | Authorized ceiling |
| Six scoped attempts, 24-hour original deadline | Existing issue policy | Changed request encoding creates new identity; replay historic/current keys | Inherited binding limit |
| Original 120-call arms | Reviewed predecessor allocation | New grant resets arm; test combined accounting | Inherited binding limit |
| Two perspectives, round-first | Existing scoped investigation | Common-model errors; keep disagreement and no independence claim | Search heuristic |
| v2 whole expressions | Completed D2 parser-binding checks | Syntactically legal selection misunderstands text; real pilot plus unchanged semantic validation | Optional candidate |
| Readable input tables | Completed D1 exact inverse | Model misreads indices despite exact codec; actual count/reference diagnostics | Optional candidate |
| 200 kB / 300 seconds | Existing bounded provider settings | Large output truncates; retain timeout and inspect smallest complete pilot | Reviewed engineering bound |
| New source revision | Actual acquired appendix | Reusing old conclusions; bind bytes and retain predecessor uncertainties | New development premise |
| Full-method hash | D6 gap analysis | Merely hashing a config supplied after execution; bind actual dossier settings/stages and recheck qualifications | Mechanism to implement |

Skeptical audit: **PASS for staged execution after F0 eligibility**, with two
material issues repaired in this plan. A new global allowance does not restore
old per-issue deadlines or exhausted task arms. An unchanged formal qualification
does not establish unchanged extraction/search. Success counts, compact prompts,
model agreement and compilation are never legal promotion criteria. Current
sources cannot answer a prospective generalization question. A failed pilot
stops that expansion and triggers a focused repair or explicit qualification.

## Execution record

Environment: project `.venv/bin/python`, CPU only (`CUDA_VISIBLE_DEVICES=-1`),
existing configured fresh Codex route with tools disabled, existing pinned
Java/Catala/Lean for the checks that require them. Never print authentication.
Use `scripts/run_assurance_new_grant.py` for bounded phase execution and status;
its exact command/inputs, commit, wall time, outputs and failure are retained.
Artifacts: `artifacts/assurance-new-grant/2026-09-29/`. Durable operating notes:
`docs/implementation/assurance-new-grant/`. Current shared-worktree changes from
other workstreams are preserved; final long verification uses a frozen copy.

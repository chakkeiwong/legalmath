# Complete investigation successor: reviewed execution plan

Date: 28 September 2026. Status: reviewed specification; execution evidence is
recorded separately. This plan consolidates `proof-carrying-assurance-next.md`
and `assurance-after-round16.md`; neither historical delivery is rewritten.
The user's new instruction authorizes **500 additional model invocations**.
The old 500-call ledger and its reservations remain unchanged. The new grant
must name that ledger's exact hash, and every dispatch, failed response and
transport timeout consumes a reservation in the new ledger before execution.
There is no permission to deploy a bank control or commission consultancy.

## Question and evidence contract

Can a persistent investigation acquire and account for source qualifications,
retain competing factual models and readings, pursue their consequential
disagreements within fixed limits, and deliver source-bound executable proposals
with independently checked evidence and explicit remaining uncertainty?

The engineering comparator is the accepted dossier integration (1,029 tests) and
round 16's opt-in local investigation. The interpretation comparator is a fresh
single-reader route at the same declared invocation budget as the ensemble; it
is not the archived 23EC46 candidate set. The new study uses source families
frozen before any new model answers. Earlier inspected families remain separate
development/backlog work. No downloaded historical circular will be described as
a prospectively published circular.

Primary engineering criteria are executed transitions, preservation of evidence,
correct rejection of invalid evidence, conformance on specified domains, and
complete regression. Primary interpretation criteria are independently supported
material conditions/answers, unsafe accepted decisions, retained correct
alternatives and unknown outcomes. Count all selected tasks, including failed
generation and unsupported encodings. Test counts, agreement, solver speed,
number of models and reduction in open questions are explanatory diagnostics.

A falsely accepted consequential reference case vetoes interpretation promotion;
it triggers investigation and repair rather than ending unrelated engineering
work. Corrupt evidence, unauthorized dispatch, unsafe executable inputs and an
exhausted required resource are continuation vetoes for the affected action.
No result establishes universal English correctness, statistical independence,
production readiness or review-cost savings without the corresponding evidence.

Artifacts live under `artifacts/assurance-successor/2026-09-28/`; documentation
under `docs/implementation/assurance-successor/`. Every phase stores commands,
input/output hashes, base commit, environment, CPU-only execution, timing,
attempt history, decision and the refreshed next action. Deterministic phases
have no random seed. Model route/version and raw proposals are retained.

## Closure map: every reported gap has a required deliverable

| Gap | Required implementation and execution | Engineering acceptance | Evidence still needed for stronger closure |
|---|---|---|---|
| G1 persistent complete investigation | Source inventory, independent initial readers, rival abstractions, structured criticism, BFS/UCT investigation, scoped follow-ups, dossier and Java outputs share a versioned investigation identity | Resume each stage; actual follow-up after disagreement; no lost reading; source changes invalidate descendants; bounded unresolved termination | A supported interpretive disposition for each material issue; no forced consensus |
| G2 complete material sources | Page-linked alternative extraction and OCR when needed; reference/edition graph; explicit disposition of all inherited PDF and authority questions | Scanned footnote/table/changed-annex challenges; retain source region and context; missing dependency blocks closure | Applicability, effectiveness and materiality need evidence; successful OCR is insufficient |
| G3 rival factual models | Reuse `abstractions.py`; add typed, versioned cross-schema mappings and admissible-domain checks; preserve actor/component/time distinctions | Missing-actor fixture survives formula agreement; wrong or partial mapping rejected; separating cases distinguish classification from formula | Each nontrivial mapping requires source-supported premises; model proposal is not approval |
| G4 legal authority reasoning | Source-bound authority/case records with applicability, treatment and priority arguments; bounded attack/defeat evaluation | Authentic but inapplicable authority, reversed priority, distinction and priority cycle all remain visible | Full judicial-corpus coverage and automatic establishment of legal authority are not implied |
| G5 complementary error detection | Provenance/dependency inventory, separate initial contexts and representations, independent source-condition reference, joint-miss analysis | Planted unanimous omission detected; no statistical independence inferred from method names; fair-budget comparator | Cross-family complementarity or review savings require real reference evidence and uncertainty analysis |
| G6 translation proof | Registered narrow certificate profile with exact formal semantics, input/tool identities and independent checker; integrate richer Catala evidence where supported | False conclusion, missing premise, wrong program, incomplete domain, unsupported expression and checker failure reject; real executable checked | Abstract interpreter theorem does not establish arbitrary Java/compiler correctness or source meaning |
| G7 duties and time | Bind one retained parent to actor-attributed events, source applicability, required performance and explicit external Java facts | Same trigger/different performance cases, historical cutoff, missing history and exact numeric boundary through actual Java | Unsourced legal dates, performance criteria and institutional classifications remain questions |
| G8 unfamiliar/future circular evidence | Frozen unfamiliar source families and independent references, equal-budget comparison, abstention and joint-miss reporting, later-source invalidation replay | All tasks remain in denominator; reference leakage and unsupported answers rejected; source change reopens decision | A small retrospective study does not establish future accuracy or a calibrated review-exemption policy |

All 232 inherited pair identities, 140 old combined assessments, 91 pending
pairs, one unencoded pair, eight parents, six authority questions and 330 PDF
materiality IDs must survive. New scoped dimensions start unassessed. Preserve
an old question even when a narrower child is executable. Never treat these
counts as confirmed legal defects or silently exclude difficult cases.

## Execution phases and repair/refresh protocol

| Phase | Required work | Fixed execution entry / retained result |
|---|---|---|
| S0 baseline and grant | Snapshot relevant dirty code/docs and prior manifests; immutable old ledger checkpoint; new grant; audit all eight gaps and command policy | `scripts/run_assurance_successor.py phase S0` / baseline and grant receipts |
| S1 source and task freeze | Freeze unfamiliar tasks before answers; retain official sources and independent reference passages; inventory inherited authority/PDF questions; implement source coverage and authority graph | `... phase S1` / task freeze, source inventory and tests |
| S2 live authorization and durable dispatch | Connect scoped v2 to explicitly granted shared allowance; retain nonrefundable dispatch, exact context/schema binding, all response bytes and failure classification | `... phase S2` / concurrency, exhaustion, interruption and replay tests |
| S3 factual and authority reasoning | Typed mappings, partial/absent mappings, adversarial distinctions, priority/treatment checks and scoped source judgments | `... phase S3` / mapping/authority checks and preserved backlog |
| S4 checked translation evidence | Register narrow independent certificate checker; execute false-certificate rejection; bind actual Java and optional rich Catala programs | `... phase S4` / certificate scope, executable and mutation evidence |
| S5 integrated investigation | Join existing source, abstraction, search, criticism and follow-up engines in one journal and evidence dossier; source changes create a new investigation revision | `... phase S5` / complete local workflow and crash/change challenges |
| S6 retained source investigations | Execute bounded v2 judgments for all inherited rows; examine authority/PDF items in bounded batches; retain unresolved materiality and all parent controls | `... phase S6` / live backlog ledger, raw judgments, repairs and uncertainty |
| S7 duty and host demonstration | Complete one supported parent/performance example and adopt exact external Java boundary; replay historical/late/incomplete facts without invented dates | `... phase S7` / real Java/reference results and sourced limits |
| S8 unfamiliar circular study | Fresh generation before peer exposure, breadth before search, source-directed follow-ups, equal-budget comparator and evidence dossier on frozen tasks | `... phase S8` / all candidate sets, witnesses, source questions and actual programs |
| S9 common-error and change evaluation | Score against frozen independent references, report unknowns and joint misses, execute source amendment/invalidation scenario | `... phase S9` / descriptive case evidence and promotion decision |
| S10 documentation | Amend unified monograph and flow chart; teach source/meaning/program distinctions through actual cases; preserve old content and dated results | `... phase S10` / compiled documents and rendered review |
| S11 full verification and successor | Full no-skip regression, certificate/dossier tamper checks, exact final manifest, per-gap closure table and refreshed successor | `... phase S11` / final report and reset memo |

The master is an executable dispatcher, not a script that marks a prose checklist
complete. A phase calls its real implementation and validators. A result can say
`ENGINEERING_PASS_WITH_OPEN_EVIDENCE`; its open issues must appear in the final
per-gap ledger. An unavailable necessary implementation is a failed/incomplete
phase, never a pass merely because a warning was emitted.

Each phase has three execution attempts. Failures preserve their commands,
inputs and output. Before retry, write a repair record identifying the failure,
change, focused reproducer and actual repair-test result. Refresh the next-phase
plan after every attempt from verified predecessors and current inputs. Changed
material inputs invalidate their descendants; unaffected immutable source and
model-response evidence may be reused with exact identities. Never reset an
attempt count or create a new campaign merely to avoid an exhausted limit.
Development smoke checks precede campaign phase acceptance and are retained when
they reveal a substantive defect. The campaign deadline is 48 hours; each model
call has a maximum 300 seconds, each bounded batch/check a declared timeout.

## Resource and command policy

The new grant is at most 500 calls, separate from the exhausted historical 500.
Initial ceilings are 160 for inherited scoped judgments, 100 for source/authority
and PDF work, 80 for unfamiliar initial breadth, 100 for investigation/evaluation,
and 60 reserved for repairs. These are planning allocations within one shared
hard ceiling, not five independent grants. Unused calls need not be spent.
Reallocation requires a recorded reason before dispatch; the total never rises.
One invocation means one actual external model request, including a timeout or
invalid output. Cached responses cannot count as a new independent judgment.

Use the installed fresh Codex provider with public source text only and tools
disabled. A second paid provider is not assumed authorized. Available local
symbolic, extraction and NLI routes can supply distinct methods; do not label
them a second independent legal interpreter. If the service offers only one
model family, record that empirical model-family independence is untested.

Fixed master commands use the repository's `.venv/bin/python`, script and phase
enum, without supplied shell fragments. Subprocess vectors for pytest, the pinned
JDK/Catala, installed Lean, OCR and document build are constructed by reviewed
adapters. Source URLs are limited to the frozen official/public reference list;
model-generated URLs are data pending validation. No arbitrary model code runs.
The application allowlist is versioned; sandbox/network approval is requested for
the narrow master command when required. CPU-only mode hides GPUs; no training,
GPU initialization, deployment or external messages are part of this campaign.

## Assumption audit and pre-mortem

| Choice / provenance | Justification and status | Failure mode | Early diagnostic |
|---|---|---|---|
| Three repair rounds / existing controllers | Reviewed finite engineering ceiling, not completeness guarantee | A difficult valid reading is left unprocessed | Preserve required perspectives and incomplete work at ceiling |
| Fresh contexts / existing Codex route | Available user-authorized generator; baseline only | Same-model shared omission | Blind source-condition extraction, distinct formal route, joint-miss ledger |
| Narrow proof fragment / successor specification | Makes a checkable proposition feasible; optional profile | Finite evidence presented as whole-compiler theorem | Explicit finite domain/semantics, exhaustive coverage and false-certificate tests |
| Retrospective unfamiliar tasks / source availability | Progress now without waiting for future publications | Prior task exposure or selection by easy grammar | Search existing corpus before freeze; retain overlap and unsupported tasks |
| Source dates and priorities / acquired documents | Hypotheses until passage supports them | Issuance confused with effectiveness; missing supersession | Separate dates, contexts and evidence; unresolved priority cycle |
| Independent reference / official examples first | Avoids model consensus as ground truth | Reference simply approves proposed readings | Freeze source-supported conditions before responses, retain unresolved reference |
| Bounded mappings / shared fact comparisons | Optional explicit bridges, not inferred synonymy | A shared missing actor makes all formulas agree | Missing-actor and wrong-unit mapping challenges |
| Small sample / initial budget | Case evidence, not statistical superiority | Selective success or unsafe review exemption | Complete denominator, no calibrated probability or automatic legal release |

The run could pass while every method misses a qualification. Therefore source
coverage, independently stated conditions and unanimous-error challenges are
separate from backend conformance. It could fail because a schema is too large
or a service is unavailable; distinguish these from evidence against a reading.
Use the smallest bounded request/check first, then increase only under the same
reviewed resource accounting. No reduction in question count is a promotion rule.

## Skeptical pre-execution audit

The prior successor documents were incomplete as an executable closure plan:
they lacked explicit G3 mappings, G4 authority/treatment tests, a G1 complete
live resolution path and a G5 joint-miss criterion. They also described an
exhausted grant despite the new authorization. This plan repairs those omissions,
preserves the inherited backlog, and separates implemented capabilities from
source/legal/evaluation conclusions. It passes the planning audit for bounded
execution; each phase must still pass its own implementation/command review.

Wrong baseline: rejected historical-only replay as unfamiliar-source evidence.
Proxy promotion: rejected agreement/test counts as legal truth. Stop conditions:
explicit budgets, evidence corruption and unsafe execution. Unfair comparison:
equal declared budgets and all tasks retained. Hidden assumptions: table above.
Stale context: baseline snapshot covers current dirty tree, not the old git HEAD
alone. Environment mismatch: test/tool identities and trusted execution recorded.
Non-answering artifacts: no phase may substitute a schema, plan or logged request
for its required real execution.

## Delivery and interpretation

The final report separates engineering correctness, checked formal propositions
and legal interpretation support. For every gap it records the implementation,
executed evidence, failed candidate, remaining uncertainty, next justified action
and whether an external decision is actually required. The decision table states
primary criterion, veto status and unsupported conclusions. The inference table
separates hard vetoes, descriptive differences, any supported statistical ranking,
default readiness and next evidence. Universal correctness and bank release
remain outside this campaign's authority.

#!/usr/bin/env python3
"""Fixed, bounded supervisor for the consolidated assurance successor."""
from __future__ import annotations
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'scripts')]
OUT = ROOT/'artifacts/assurance-successor/2026-09-28'
DOC = ROOT/'docs/implementation/assurance-successor'
PLAN = ROOT/'docs/plans/assurance-successor-execution.md'
PHASES = tuple('S'+str(i) for i in range(12))
OLD_LEDGER = ROOT/'artifacts/interpretation/round7/live-allowance.json'
GRANT = OUT/'grant.json'
PY = ROOT/'.venv/bin/python'
MAX_ATTEMPTS = 3


def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now(): return datetime.now(timezone.utc).isoformat()
def save(p, value):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(value, sort_keys=True, indent=2)+'\n'); tmp.replace(p)
def rel(p): return Path(p).resolve().relative_to(ROOT).as_posix()


def state():
    return read(OUT/'state.json') if (OUT/'state.json').exists() else {
        'protocol': 'assurance-successor.v1', 'started_at': now(), 'started_epoch': time.time(),
        'phases': {p: {'status': 'PLANNED', 'attempts': []} for p in PHASES}}


def baseline(work):
    previous = read(OLD_LEDGER)
    if previous['maximum'] != 500 or len(previous['calls']) != 500:
        raise RuntimeError('Unexpected predecessor allowance')
    grant = {'schema':'legalmath.additional-grant.v1', 'grant_id':'user.2026-09-28.additional500',
        'authorized_calls':500,
        'authorization':'User: you have another 500 allowance. Ensure successor covers all issues, review thoroughly and execute.',
        'predecessor':{'path':'../../interpretation/round7/live-allowance.json','sha256':sha(OLD_LEDGER)},
        'ledger':'live-allowance.json'}
    if GRANT.exists() and read(GRANT) != grant: raise RuntimeError('Grant identity mismatch')
    save(GRANT, grant)
    ledger = OUT/'live-allowance.json'
    if not ledger.exists(): save(ledger, {'maximum':500,'calls':[]})
    from legalmath.interpretation.assurance.grants import GrantedAllowance
    checked = GrantedAllowance(GRANT).verify()
    files = []
    for directory in ('src','scripts','tests','docs/plans','docs/implementation','docs/monograph','docs/proposal'):
        files.extend(p for p in (ROOT/directory).rglob('*') if p.is_file() and
            p.suffix in ('.py','.java','.json','.md','.tex','.bib') and '__pycache__' not in p.parts
            and 'review' not in p.parts)
    files += [OLD_LEDGER, ROOT/'artifacts/interpretation/round15/remaining-work.json',
              ROOT/'artifacts/interpretation/round16/phase-results.json',
              ROOT/'artifacts/proof-carrying-assurance/verified-execution-v3/final-report.json']
    hashes = {rel(p):sha(p) for p in sorted(set(files))}
    with zipfile.ZipFile(work/'baseline.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name in hashes: archive.write(ROOT/name, name)
    save(work/'inputs.json', hashes)
    remaining = read(ROOT/'artifacts/interpretation/round15/remaining-work.json')
    save(work/'remaining-work.json', remaining)
    rows = remaining['restored_pair_rows']
    if len(rows) != 232 or len({(r['case_id'],r['claim_id'],r['candidate_id']) for r in rows}) != 232:
        raise RuntimeError('Inherited pair universe changed')
    return {'status':'BASELINE_AND_NEW_GRANT_BOUND', 'grant':checked, 'material_files':len(hashes),
            'backlog_pairs':len(rows), 'release_eligible':False}


def refresh(current):
    next_phase = next((p for p in PHASES if current['phases'][p]['status'] != 'PASSED'), None)
    used = len(read(OUT/'live-allowance.json')['calls']) if (OUT/'live-allowance.json').exists() else 0
    value = {'at':now(), 'next_phase':next_phase, 'live_used':used,'live_remaining':500-used,
        'phases':{p:{'status':r['status'],'attempts_consumed':len(r['attempts']),
                     'attempts_remaining':MAX_ATTEMPTS-len(r['attempts'])} for p,r in current['phases'].items()},
        'open_evidence':{p:r.get('open_evidence',[]) for p,r in current['phases'].items() if r.get('open_evidence')},
        'next_action':'Repair current failed phase before retry' if next_phase and current['phases'][next_phase]['status']=='FAILED'
                      else 'Execute '+next_phase if next_phase else 'Review per-gap outcome and remaining external evidence',
        'release_eligible':False}
    save(OUT/'next-phase-plan.json', value)
    return value


def phase(name):
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT/'.master.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        current = state(); row = current['phases'][name]
        if time.time()-current['started_epoch'] > 48*3600: raise RuntimeError('Campaign deadline exhausted')
        for p in PHASES[:PHASES.index(name)]:
            if current['phases'][p]['status'] != 'PASSED': raise RuntimeError('Predecessor incomplete: '+p)
            prior = current['phases'][p]['attempts'][-1]
            if sha(ROOT/prior['manifest']) != prior['sha256']: raise RuntimeError('Changed predecessor manifest')
            record = read(ROOT/prior['manifest'])
            for f,h in record['outputs'].items():
                if sha(ROOT/f) != h: raise RuntimeError('Changed predecessor evidence: '+f)
        if row['status'] == 'PASSED': return read(ROOT/row['attempts'][-1]['manifest'])['result']
        if len(row['attempts']) >= MAX_ATTEMPTS: raise RuntimeError('Fixed phase attempt ceiling exhausted')
        if row['attempts']:
            repair = DOC/f'{name}-repair-{len(row["attempts"])}.json'
            if not repair.exists() or read(repair).get('focused_check_passed') is not True:
                raise RuntimeError('Executed focused repair record required before retry')
        attempt = len(row['attempts'])+1; work = OUT/name/f'attempt-{attempt:02}'
        work.mkdir(parents=True,exist_ok=False)
        row['attempts'].append({'status':'RESERVED','directory':rel(work)})
        row['status']='RUNNING'; save(OUT/'state.json',current)
        begun=time.monotonic()
        record={'phase':name,'attempt':attempt,'started_at':now(),'plan':rel(PLAN),'plan_sha256':sha(PLAN),
            'git_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
            'python':sys.version,'executable':str(Path(sys.executable).resolve()),
            'cpu_gpu':'CPU; CUDA_VISIBLE_DEVICES=-1','seeds':'N/A for deterministic checks; provider sampling is external',
            'command':[str(PY),str(Path(__file__)), 'phase',name],
            'controller_sha256':sha(__file__), 'result':None}
        os.environ['CUDA_VISIBLE_DEVICES']='-1';os.environ['HF_HUB_OFFLINE']='1'
        try:
            if name=='S0': result=baseline(work)
            else:
                from assurance_successor_phases import execute
                result=execute(name,work)
            if not isinstance(result,dict) or result.get('execution_complete') is False:
                raise RuntimeError('Phase execution incomplete: '+str(result))
            record.update(status='PASSED',result=result)
            row['status']='PASSED';row['open_evidence']=result.get('open_evidence',[])
        except BaseException as exc:
            record.update(status='FAILED',error=type(exc).__name__+': '+str(exc))
            row['status']='FAILED'
            raise
        finally:
            record.update(finished_at=now(),wall_seconds=round(time.monotonic()-begun,3),
                outputs={rel(p):sha(p) for p in work.rglob('*') if p.is_file() and p.name!='manifest.json'})
            save(work/'manifest.json',record)
            row['attempts'][-1]={'manifest':rel(work/'manifest.json'),'sha256':sha(work/'manifest.json'),'status':record['status']}
            save(OUT/'state.json',current);refresh(current)
        return result


def main():
    parser=argparse.ArgumentParser(); parser.add_argument('action',choices=['phase','status','run'])
    parser.add_argument('phase',nargs='?',choices=PHASES); args=parser.parse_args()
    if args.action=='status': result=refresh(state())
    elif args.action=='phase':
        if not args.phase:parser.error('phase required')
        result=phase(args.phase)
    else:
        for p in PHASES:
            print('Executing '+p,flush=True);phase(p)
        result=refresh(state())
    print(json.dumps(result,indent=2))


if __name__=='__main__': main()
